#include <stdio.h>
main()
{
Char i ,j;
Int c=14;
i=j=3;
while( ++i <= c )
{
int j = 1;
printf("\nNr1 = %c Nr2 = %d", 64+ i, c2);
} do;
}
