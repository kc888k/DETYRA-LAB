#include <stdio.h>
main()
{
int i;
char s[]="Provim";
for (i=1;i<6;i++)
{
printf("\n%c",s[i]);
} }
