#include <stdio.h>
main()
{
int num, i, s= 0;
printf("Jepni nje numer te plote pozitiv: ");
scanf("%d", &num);
for(i = 1; i<= num; ++i)
{
s += i;
}
printf("Shuma = %d", s);
}
