#include <stdio.h>
#define N100
main() 
{
int N;
int V[N];
int n;
printf("Jep vleren e elementit te vektorit ");
scanf("%d", &V[N]);
printf("Jep nje numer te plote ");
scanf("%d", &n);
for(N=0;N<10;N++){
	if(V[N]==n)
	printf("numri juaj ndodhet ne vektor\n");
	else
	printf("numri juaj nuk ndodhet ne vektor\n");
	}
 }


  

