# include <stdio.h>
main()
{
int i;
double nr, shuma = 0.0;
for(i=1; i <= 10; ++i)
{
printf("Shkruaj numrin %d: ",i);
scanf("%lf", &nr);
// n�se p�rdoruesi shtyp num�r negativ, cikli nd�rpritet
if(nr < 0.0)
{
break;
}
shuma += nr; // shuma = shuma + nr;
}
printf("Shuma = %.2lf", shuma);
}
