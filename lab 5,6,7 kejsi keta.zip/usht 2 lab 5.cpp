#include <stdio.h>
main()
{
int num, i, s;
printf("Jepni nje numer te plote pozitiv: ");
scanf("%d", &num);
s=0; i=1;
while (i <= num)
{
s += i;
i=i+1;
}
printf("Shuma = %d", s);
}
